This program requires OpenAI gym, please modify the line
	sys.path.append("/usr/local/lib/python2.7/site-packages") # path to the folder containning 'gym'
before running mdp.py